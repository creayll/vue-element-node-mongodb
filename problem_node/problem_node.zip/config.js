module.exports = {
	api:'api1.0',    //api版本
	mongodb:'mongodb://localhost:27017/test1',
	push:{
		AppKey:'3020f81b04a8483ca50af1bb',
		Secret:'995a067d5662f6b45c10dd87'
	}
}
