var config=require('../config')
class commonbase {
	constructor(){
		this.config=config
	}
	check(){
		console.log("11")
	}
}
module.exports=commonbase